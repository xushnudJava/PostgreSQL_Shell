package imtihon;

public class masala3 {
    public static void main(String[] args) {
        Book book = new Book();
        book.menu();
    }

}
